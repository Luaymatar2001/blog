

<?php $__env->startSection('title', 'news Index'); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
        <?php if(session()->has('statusEdit')): ?>
        <?php if(session('statusEdit')): ?>
        <script>
            $(document).ready(function() {
                                        swal({
                                            icon: "success",
                                            text: "the Edit Process is success \n Do you want to go back Edit row ?"
                                        }).then(function name(params) {
                                            $id = '<?php echo e(session("id")); ?>';
                                            $page ='<?php echo e(session("pageNumber")); ?>';
                                            if ($page == 0) {
                                                window.location.href = <?php echo e(route('news.index')); ?>+'#ID'+$id;
                                            }else{
                                                window.location.href =<?php echo e(route('news.index')); ?>+$page+'#ID'+$id;
                                            }
                                  
                                  
                                         
                                        }
                                         
                                        )
                                    });
        </script>
        <?php else: ?>
        <script>
            swal("Faild to add new profession ! ", {
                                        className: "red-bg",
                                    });
        </script>
        <?php endif; ?>
        <?php endif; ?>
        <!-- /.row -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">

                        </h3>

                        <div class="card-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                                <input type="text" name="table_search" class="form-control float-right"
                                    placeholder="Search">

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover table-bordered table-striped text-nowrap">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Subject</th>
                                    <th>Source news</th>
                                    <th>iamge</th>
                                    <th>user</th>
                                    <th>Create At</th>
                                    <th>Updated At</th>
                                    <th>Settings</th>

                                </tr>
                            </thead>
                            <tbody>


                                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singe_news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="ID<?php echo e($singe_news->id); ?>">
                                    <td><?php echo e($singe_news->id); ?></td>
                                    <td><?php echo e($singe_news->title); ?></td>
                                    <td><?php echo e($singe_news->subject); ?></td>
                                    <td> <img src="<?php echo e($singe_news->image_url); ?>" alt="image empty" width="200"
                                            srcset=""></td>
                                    <td><?php echo e($singe_news->source_news); ?>


                                    </td>
                                    <td><?php echo e($singe_news->user->name); ?></td>
                                    <td><?php echo e($singe_news->created_at); ?></td>
                                    <td><?php echo e($singe_news->updated_at); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            
                                            <form method="POST" action="<?php echo e(route('news.destroy',$singe_news->slug)); ?>" ,
                                                id="sub_Delete<?php echo e($singe_news->id); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger delete<?php echo e($singe_news->id); ?>">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                                <script>
                                                    $('.delete<?php echo e($singe_news->id); ?>').click(function(e){
                                                          e.preventDefault()
                                                               let confirm =swal("Are you sure delete this record ?", {
                                                               dangerMode: true,
                                                                    buttons: {
                                                                      cancel: "cancel",
                                                                       ok: {
                                                                       text: "ok",
                                                                       value: "ok",
                                                                         },
                                                                        },  }).then(function(e){
                                                                     if(e == "ok"){
                                                                      $('#sub_Delete<?php echo e($singe_news->id); ?>').submit();
                                                                   }
                                                               });
                                        
                                                        });
                                                </script>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                    <!-- /.card-body -->
                    <div class="container">
                        <hr>
                        <div class="row">
                            <div class="hint-text col-10"><b> <?php echo e($news->count()); ?></b> items out of
                                <b><?php echo e($news->total()); ?></b> in
                                <b><?php echo e($news->lastPage()); ?></b> pages
                            </div>
                            <!-- 2 items out of 100 in 10 pages -->
                            <div class="col-1" style="border :10px;">
                                <?php echo e($news->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <script>
        const hashParams = new URLSearchParams(window.location.hash.slice(1));
                                const sectionId = hashParams.get('section');
                                let IDHash = hashParams+"";
                                let ID =IDHash.replace('=','')+"";
                                const myElement = document.getElementById(ID);
                                 myElement.style.backgroundColor = '#A9A9A9';  
                              
                             
                                    $('#'+ID).animate({
                                        backgroundColor: '#A9A9A9',
                                        opacity: "toggle"
                                    }, 700, "swing" ,function(){
                                   $('#'+ID).animate({backgroundColor: '#ffffff',
                                     opacity: "toggle"},700);
                                   });
                                
                                setTimeout(() => {
                                myElement.style.backgroundColor = '';
                                }, 3000 );
                                
                            
    </script>
    <!-- /.container-fluid -->
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\news_site\resources\views/news/index.blade.php ENDPATH**/ ?>