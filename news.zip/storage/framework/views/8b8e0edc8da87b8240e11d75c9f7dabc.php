<?php if (isset($component)) { $__componentOriginal25c458fccfeea57bebe43c95432619d1 = $component; } ?>
<?php $component = App\View\Components\PageMenu::resolve(['breadcrumbs1' => 'details of '.e($news_details->title).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PageMenu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
	<!--Sidebar Page Container-->
	<div class="sidebar-page-container">
		<div class="auto-container">
			<div class="row clearfix">

				<!--Content Side-->
				<div class="content-side col-sm-12">
					<div class="news-detail">
						<div class="inner-box">
							<div class="image">
								<img src="<?php echo e($news_details->image_url); ?>" alt="" />
							</div>
							<div class="lower-content">
								<div class="content">
									<ul class="post-info">
										<li><span
												class="icon flaticon-chat-comment-oval-speech-bubble-with-text-lines"></span>
											<?php echo e($news_details->reviews()->count()); ?></li>


										
									</ul>
									<ul class="post-meta">
										<li>before : <?php echo e($news_details->time_format); ?> </li>
										<li>Post By: <?php echo e($news_details->user->name); ?></li>
										<li> <a href="<?php echo e(route('show.email' , $news_details->user->id)); ?>"
												style="text-decoration: none; color:#ffffff">Send Eamil :<i
													class="fas fa-paper-plane fa-lg" style="color:#ffffff"></i></a></li>

									</ul>

									<h3><?php echo e($news_details->title); ?></h3>
									<div class="text">
										<p><?php echo e($news_details->subject); ?> </p>
										<p><?php echo e($news_details->content); ?></p>
										
										
									</div>
								</div>
							</div>
						</div>



					</div>

					<!--Comments Area-->
					<div class="comments-area">

						<div class="group-title">
							<h2>Comments <?php echo e($news_details->reviews()->count()); ?></h2>
						</div>


						<?php $__currentLoopData = $news_details->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="comment-box" id="<?php echo e($review->id); ?>">
							<div class="comment">
								<div class="author-thumb"><img src="<?php echo e(asset('images/resource/author-7.jpg')); ?>" alt="">
								</div>
								<div class="comment-inner">
									<div class="comment-info clearfix"><strong><?php echo e($review->name); ?> </strong>
										<div class="comment-time"><?php echo e($review->time_format); ?></div>
									</div>


									<div class="text"><?php echo e($review->subject); ?>

									</div>
									<div class="text"><?php echo e($review->content); ?>

									</div>
								</div>
								<ul class="review">
									<?php for($i = 0; $i < 5; $i++): ?> <?php if($i < $review->rate): ?> <li
											style="display: inline-block;">

											<i class="fas fa-star" style="color: #005eff;"></i>
										</li>
										<?php else: ?>
										<li style="display: inline-block;"><i class="far fa-star"
												style="color: #005eff;"></i>
										</li>
										<?php endif; ?>
										<?php endfor; ?>
								</ul>

							</div>

						</div>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div>


					<!-- Comment Form -->
					<div class="comment-form">

						<div class="group-title">
							<h2>Leave a Reply</h2>
						</div>

						<!-- Comment Form -->
						<div class="comment-form">
							<!-- Comment Form -->
							<form method="post" action="<?php echo e(route('review.store')); ?>">
								<?php echo csrf_field(); ?>
								<div class="row clearfix">
									<input type="hidden" name="news_id" value="<?php echo e($news_details->id); ?>">
									<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<input type="text" name="name" placeholder="Full Name" required>
										<?php $__errorArgs = ['news_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<small class="text-danger">
											<?php echo e($message); ?>

										</small>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<select name="rate" id="rate" required>
											<option value="5">Rate This Post (5 Stars)</option>
											<option value="4">Good Job! 4 stars.</option>
											<option value="3">Nice Work! 3 stars.</option>
											<option value="2">Not Bad, but can be better... 2 stars.</option>
											<option value="1">I don't like it at all.. 1 star.</option>
										</select>
										<?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<small class="text-danger">
											<?php echo e($message); ?>

										</small>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>

									<div class="col-lg-6 col-md-6 col-sm-12 form-group">
										<input type="email" name="email" placeholder="Email" required>
										<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<small class="text-danger">
											<?php echo e($message); ?>

										</small>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>

									<div class="col-lg-6 col-md-6 col-sm-12 form-group">
										<input type="text" name="subject" placeholder="Subject" required>
										<?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<small class="text-danger">
											<?php echo e($message); ?>

										</small>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>

									<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<textarea name="content" placeholder="Message"></textarea>
										<?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<small class="text-danger">
											<?php echo e($message); ?>

										</small>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>

									<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<button class="theme-btn comment-btn" type="submit" name="submit-form">Post
											Comments</button>
									</div>

								</div>
							</form>

						</div>
						<!--End Faq Form -->

					</div>



				</div>

				<!--Sidebar Side-->
				

			</div>
		</div>
	</div>
	<script>
		const hashParams = new URLSearchParams(window.location.hash.slice(1));
		                                const sectionId = hashParams.get('section');
		                                let IDHash = hashParams+"";
		                                let ID =IDHash.replace('=','')+"";
		                                const myElement = document.getElementById(ID);
		                                 myElement.style.backgroundColor = '#d3d3d3';  
		                              
		                             
		                                    $('#'+ID).animate({
		                                        backgroundColor: '#d3d3d3',
		                                        opacity: "toggle"
		                                    }, 700, "swing" ,function(){
		                                   $('#'+ID).animate({backgroundColor: '#d3d3d3',
		                                     opacity: "toggle"},700);
		                                   });
		                                
		                                setTimeout(() => {
		                                myElement.style.backgroundColor = '';
		                                }, 3000 );
		                                
		                            
	</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal25c458fccfeea57bebe43c95432619d1)): ?>
<?php $component = $__componentOriginal25c458fccfeea57bebe43c95432619d1; ?>
<?php unset($__componentOriginal25c458fccfeea57bebe43c95432619d1); ?>
<?php endif; ?><?php /**PATH C:\web\news_site\resources\views/blog/blog_details.blade.php ENDPATH**/ ?>