<a class="nav-link" data-toggle="dropdown" href="#">
    
    <i class="fas fa-bell fa-lg"></i>
    <span class="badge badge-danger navbar-badge" id="unread_count"><?php echo e($unread); ?></span>
</a>
<div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" id="div_notification">
    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e($item->data['link']); ?>?nid=<?php echo e($item->id); ?>#<?php echo e($item->data['ID'] ?? 0); ?>" class="dropdown-item">
        <!-- Message Start -->
        <div class="media">
            
            <div class="mr-3">
                <i class="<?php echo e($item->data['icon']); ?> fa-2x"></i>
            </div>
            
            <div class="media-body">
                <h3 class="dropdown-item-title">
                    
                    
                </h3>
                <p class="text-sm"><?php echo e($item->data['body']); ?></p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i><?php echo e($item->updated_at->diffForHumans()); ?>

                </p>
            </div>
        </div>
        <!-- Message End -->
    </a>
    <div class="dropdown-divider"></div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
</div><?php /**PATH C:\web\news_site\resources\views/components/admin-notification.blade.php ENDPATH**/ ?>