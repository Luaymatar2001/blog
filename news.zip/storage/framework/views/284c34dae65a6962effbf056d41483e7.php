<?php if (isset($component)) { $__componentOriginal25c458fccfeea57bebe43c95432619d1 = $component; } ?>
<?php $component = App\View\Components\PageMenu::resolve(['breadcrumbs1' => 'blog page'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('PageMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PageMenu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <div class="news-block-two col-lg-6 col-md-12 col-sm-12">
        <div class="inner-box">
            <div class="image">
                <a href="blog-detail.html"><img src="<?php echo e($item->image_url); ?>" alt="" /></a>
            </div>
            <div class="lower-content">
                <div class="content">
                    <ul class="post-info">
                        <li><span class="icon flaticon-chat-comment-oval-speech-bubble-with-text-lines"></span>
                            <?php echo e($item->reviews()->count()); ?></li>
                        
                    </ul>
                    <ul class="post-meta">
                        <li><?php echo e($item->time_format); ?></li>
                        <li>Post By: <?php echo e($item->user->name); ?></li>
                        <li>
                            <ul class="review">
                                <?php
                                $starRating = $item->reviews()->count() > 0 ?
                                ceil( $item->reviews()->sum('rate')/$item->reviews()->count())
                                : 0;

                                ?>

                                <?php for($i = 0; $i < 5; $i++): ?> <?php if($i < $starRating): ?> <li><i class="fas fa-star"
                                        style="color: #e5e7eb;"></i>
                        </li>
                        <?php else: ?>
                        <li><i class="far fa-star" style="color: #e5e7eb;"></i></li>
                        <?php endif; ?>
                        <?php endfor; ?>
                    </ul>
                    </li>
                    </ul>
                    <h3><a href="blog-detail.html"><?php echo e($item->title); ?></a>
                    </h3>
                    <div class="text"><?php echo e($item->subject); ?></div>
                    <a href="<?php echo e(route('news.show' , $item->slug)); ?>" class="theme-btn btn-style-five"><span
                            class="txt">read
                            more</span></a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal25c458fccfeea57bebe43c95432619d1)): ?>
<?php $component = $__componentOriginal25c458fccfeea57bebe43c95432619d1; ?>
<?php unset($__componentOriginal25c458fccfeea57bebe43c95432619d1); ?>
<?php endif; ?><?php /**PATH C:\web\news_site\resources\views/blog/home.blade.php ENDPATH**/ ?>